//AQUI SE MUESTRA LA FILTRACION POR BUSQUEDA 
document.getElementById('searchInput').addEventListener('input', function () {

    const query = this.value.toLowerCase();
    const cursos = document.querySelectorAll('#coursesContainer .card');

    cursos.forEach(curso => {

        const title = curso.querySelector('.card-title').textContent.toLowerCase();

        if (title.includes(query)) {
            curso.style.display = 'block';
        } else {
            curso.style.display = 'none';
        }

    });

});