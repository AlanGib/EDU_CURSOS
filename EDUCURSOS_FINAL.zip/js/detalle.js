//LOS CURSOS ESTAN EN UN ARREGLO
const cursos = [
    {
        id: 1,
        titulo: "Introducción a la Programación",
        duracion: "40 horas",
        modalidad: "Online/Presencial",
        nivel: "Básico",
        imagen: "img/IntProg.jpg",
        descripcion: "Aprender los conceptos básicos de la programación.",
        requisitos: "Ser mayor de edad"
    },
    {
        id: 2,
        titulo: "Desarrollo Web con HTML y CSS",
        duracion: "30 horas",
        modalidad: "Online/Presencial",
        nivel: "Intermedio",
        imagen: "img/HtmlCss.jpg",
        descripcion: "Aprender a crear sitios web modernos.",
        requisitos: "Conocimientos básicos de computación"
    },
    {
        id: 3,
        titulo: "JavaScript Avanzado",
        duracion: "50 horas",
        modalidad: "Online/Presencial",
        nivel: "Avanzado",
        imagen: "img/JScript.jpg",
        descripcion: "Dominar JavaScript moderno.",
        requisitos: "Conocimientos previos de JS"
    },
    {
        id: 4,
        titulo: "Python para Data Science",
        duracion: "60 horas",
        modalidad: "Online/Presencial",
        nivel: "Intermedio",
        imagen: "img/Py.png",
        descripcion: "Aprender análisis de datos con Python.",
        requisitos: "Bases de programación"
    },
    {
        id: 5,
        titulo: "Diseño Gráfico con Photoshop",
        duracion: "35 horas",
        modalidad: "Online/Presencial",
        nivel: "Básico",
        imagen: "img/Photoshp.jpg",
        descripcion: "Aprender diseño gráfico profesional.",
        requisitos: "Ninguno"
    },
    {
        id: 6,
        titulo: "Marketing Digital",
        duracion: "25 horas",
        modalidad: "Online/Presencial",
        nivel: "Intermedio",
        imagen: "img/Marketing.webp",
        descripcion: "Aprender estrategias de marketing online.",
        requisitos: "Ninguno"
    },
    {
        id: 7,
        titulo: "Inglés Conversacional",
        duracion: "45 horas",
        modalidad: "Online/Presencial",
        nivel: "Básico",
        imagen: "img/Ingles.png",
        descripcion: "Mejorar tu inglés hablado.",
        requisitos: "Ninguno"
    },
    {
        id: 8,
        titulo: "Machine Learning Fundamentals",
        duracion: "70 horas",
        modalidad: "Online/Presencial",
        nivel: "Avanzado",
        imagen: "img/MachineLearning.webp",
        descripcion: "Introducirse al Machine Learning.",
        requisitos: "Python básico"
    },
    {
        id: 9,
        titulo: "Administración de Proyectos",
        duracion: "40 horas",
        modalidad: "Online/Presencial",
        nivel: "Intermedio",
        imagen: "img/AdministracionProyectos.jpg",
        descripcion: "Aprender la gestión eficiente de proyectos.",
        requisitos: "Ninguno"
    },
    {
        id: 10,
        titulo: "Ciberseguridad Básica",
        duracion: "30 horas",
        modalidad: "Online/Presencial",
        nivel: "Básico",
        imagen: "img/CyberSeguridad.jpg",
        descripcion: "Conocer los Fundamentos de seguridad informática.",
        requisitos: "Ninguno"
    }
];


//SE RECUPERA LA WISHLISH DEL LOCALSTORAGE

let wishlist = [];

let lista_wishlist = localStorage.getItem("wishlist");

if (lista_wishlist) {
    wishlist = JSON.parse(lista_wishlist);
}

//SE CONFIGURA LA ACTUALIZACION AUTOMATICA DE LA PAGINA DEPENDIENDO DEL CURSO
const params = new URLSearchParams(window.location.search);
const idCurso = params.get("id");

const curso = cursos.find(c => c.id == idCurso);



//PARA CADA CURSO SELECCIONADA, SE EJECUTARA LO SIGUIENTE
if (curso) {
    document.getElementById("tituloCurso").textContent = curso.titulo;
    document.getElementById("objetivoCurso").textContent = curso.descripcion;
    document.getElementById("requisitosCurso").textContent = curso.requisitos;
    document.getElementById("duracionCurso").textContent = curso.duracion;
    document.getElementById("modalidadCurso").textContent = curso.modalidad;
    document.getElementById("imagenCurso").src = curso.imagen;
    
    const boton_wish = document.getElementById("boton_wishlist");


    //EVENTO DEL BOTON PARA AGREGARA LA WISHLIST
    boton_wish.addEventListener("click", () => {
        const existe = wishlist.some(c => c.id == curso.id);
        if (!existe) {
            wishlist.push(curso);
            localStorage.setItem("wishlist", JSON.stringify(wishlist));
            new bootstrap.Modal(document.getElementById("modalExito")).show();
        } else {
            new bootstrap.Modal(document.getElementById("modalRepetido")).show();
           
        }

        console.log(wishlist);
    });


    const boton_eliminar=document.getElementById("boton_eliminar_wishlist");


    //EVENTO DEL BOTON PARA ELIMINAR DE LA WISHLIST
    boton_eliminar.addEventListener("click",()=>{
        const existe = wishlist.some(c => c.id == curso.id);
        if(existe){
            wishlist= wishlist.filter(c => c.id != curso.id);
            localStorage.setItem("wishlist", JSON.stringify(wishlist));
            new bootstrap.Modal(document.getElementById("modalEliminado")).show();
        }
        else{
            new bootstrap.Modal(document.getElementById("modalNoExiste")).show();
        }

        console.log(wishlist);
        
    });

}


