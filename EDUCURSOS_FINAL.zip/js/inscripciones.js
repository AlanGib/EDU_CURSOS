const boton_inscribir = document.querySelector('.Enviar');

const inputnombre = document.querySelector("#nombre");
const inputapellidopaterno = document.querySelector("#apellidoPaterno");
const inputapellidomaterno = document.querySelector("#apellidoMaterno");
const inputemail = document.querySelector("#email");
const select = document.getElementById("curso");
const inputcomentario = document.querySelector("#comentarios");

let inscripciones = [];


const inscripcionesGuardadas = localStorage.getItem("inscripciones");


if (inscripcionesGuardadas) {
    inscripciones = JSON.parse(inscripcionesGuardadas) || [];
}

console.log(inscripciones);



//RECUPERAR LOS ELEMENTOS DE LA WISHLIST EN EL SELECT

let wishlist = JSON.parse(localStorage.getItem("wishlist")) || [];


//AQUI SE AGREGAN LOS CURSOS DE LA WISHLIST AL SELECT DEL FORMULARIO
wishlist.forEach(curso => {
    const option = document.createElement("option");
    option.value = curso.id;
    option.textContent = curso.titulo;
    select.appendChild(option);
});





const formulario = document.getElementById("formInscripcion");


//AQUI OCURRE LA VALIDACION DE LA INFORMACION DEL FORMULARIO
formulario.addEventListener("submit", function (e) {

    e.preventDefault();
    e.stopPropagation();

    formulario.classList.add("was-validated");

    if (!formulario.checkValidity()) {
        return;
    }

    const modalidadSeleccionada =document.querySelector('input[name="modalidad"]:checked');

    
    let id = Date.now();
    let modalidadSeleccionado = modalidadSeleccionada.value;
    let nombreSeleccionado = inputnombre.value;
    let apellidoPaternoSeleccionado = inputapellidopaterno.value;
    let apellidoMaternoSeleccionado = inputapellidomaterno.value;
    let emailSeleccionado = inputemail.value;
    let comentarioSeleccionado = inputcomentario.value;
    let estadoSeleccionado = 'Registrado';
    let cursoSeleccionado = select.options[select.selectedIndex].text;


    const inscripcion = {
        id: id,
        nombre: nombreSeleccionado,
        apellidoPaterno: apellidoPaternoSeleccionado,
        apellidoMaterno: apellidoMaternoSeleccionado,
        email: emailSeleccionado,
        curso: cursoSeleccionado,
        modalidad: modalidadSeleccionado,
        comentario: comentarioSeleccionado,
        estado: estadoSeleccionado
    };

    const existe = inscripciones.some(c => c.email == inscripcion.email && c.curso == inscripcion.curso);
    if (existe) {
        alert("Ya esta inscrito a este curso, vuelva a intentarlo con otro.")
    }
    else {
        inscripciones.push(inscripcion);
        localStorage.setItem("inscripciones", JSON.stringify(inscripciones));
        console.log(inscripciones);
        formulario.reset();
        formulario.classList.remove("was-validated");
        window.location.href = "mis_cursos.html";
    }

});
