let inscripciones = JSON.parse(localStorage.getItem("inscripciones")) || [];
const tabla = document.getElementById("tablaInscripciones");
let indexAEliminar = null;




//FUNCION PARA CANCELAR LA INSCRIPCION SELECCIONADA
function cancelarInscripcion(index) {

    indexAEliminar = index;

    const modal = new bootstrap.Modal(
        document.getElementById('modalConfirmacion')
    );

    modal.show();
}





//AQUI SE RENDERIZA LA TABLA DE INSCRIPCIONES
function renderTabla() {

    const tabla = document.getElementById("tablaInscripciones");

    tabla.innerHTML = "";

    if (inscripciones.length === 0) {
        tabla.innerHTML = `
            <tr>
                <td colspan="6" class="text-center">No hay inscripciones registradas</td>
            </tr>
        `;
        return;
    }

    inscripciones.forEach((insc, index) => {

        tabla.innerHTML += `
            <tr>
                <td>${insc.id}</td>
                <td>${insc.nombre + " " + insc.apellidoPaterno + " " + insc.apellidoMaterno}</td>
                <td>${insc.curso}</td>
                <td>${insc.modalidad}</td>
                <td>${insc.estado}</td>
                <td>
                    ${insc.estado !== "Cancelada"
                ? `<button class="btn btn-danger btn-sm" onclick="cancelarInscripcion(${index})">Cancelar</button>`
                : ''
            }
                </td>
            </tr>
        `;
    });
}


//AQUI SE LLAMA AL EVENTO DEL BOTON DE CONFIRMAR LA ELIMINACION DE LA INSCRIPCION
document.getElementById("btnConfirmarCancelacion").addEventListener("click", function () {

    if (indexAEliminar !== null) {

        inscripciones[indexAEliminar].estado = "Cancelada";

        inscripciones = inscripciones.filter(c =>
            c.id != inscripciones[indexAEliminar].id
        );

        localStorage.setItem("inscripciones", JSON.stringify(inscripciones));

        renderTabla();
        location.reload(); 
    }

    const modal = bootstrap.Modal.getInstance(document.getElementById('modalConfirmacion'));
    modal.hide();

    indexAEliminar = null;
});






//AQUI SE GRAFICAN LOS CURSOS

function grafica() {
    document.addEventListener("DOMContentLoaded", function () {

        const ctx = document.getElementById('graficoCursos').getContext('2d');


        let contador = {};

        // Contar solo inscripciones activas
        inscripciones.forEach(insc => {
            if (insc.estado !== "Cancelada") {
                contador[insc.curso] = (contador[insc.curso] || 0) + 1;
            }
        });

        const labels = Object.keys(contador);
        const data = Object.values(contador);

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Número de Inscritos',
                    data: data,
                    backgroundColor: 'rgba(56, 96, 140, 0.7)',
                    borderColor: 'rgba(56, 96, 140, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });

    });

}






//AQUI SE EXPORTA LAS INSCRIPCIONES
document.getElementById("btnExportarTxt").addEventListener("click", () => {

    let contenido = "LISTA DE INSCRIPCIONES";

    inscripciones.forEach((insc, index) => {
        contenido += `
        ID: ${index + 1}
        Nombre: ${insc.nombre} ${insc.apellidoPaterno}  ${insc.apellidoMaterno}
        Curso: ${insc.curso}
        Modalidad: ${insc.modalidad}
        Estado: ${insc.estado}
        -------------------------
        `;
    });

    const blob = new Blob([contenido], { type: "text/plain" });
    const enlace = document.createElement("a");

    enlace.href = URL.createObjectURL(blob);
    enlace.download = "inscripciones.txt";
    enlace.click();
});



renderTabla();
grafica();